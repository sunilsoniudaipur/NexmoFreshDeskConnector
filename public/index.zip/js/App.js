var app = angular.module('app', []);

app.constant('constants',{

    APP_BASE_URL:"",
    APP_NAME:"TapReach"

});